# Skotokoto / eVoucha Orchestration API — v0.1

A provider-agnostic orchestration API for Skotokoto, the WhatsApp-facing product of eVoucha Technologies.

## What is implemented

- User creation by SA E.164 cellphone number
- 5-digit PIN hashing with scrypt + pepper
- Wallet and balance
- 1Voucher cash-in adapter (mock provider)
- Wallet-to-wallet transfers
- Bank voucher withdrawal adapter (`BANK_1`, mock provider)
- Policy payment adapter (`POLICY_1`, mock provider)
- Transaction history
- PostgreSQL ledger tables
- Idempotency keys for financial write operations
- Provider transaction and webhook tables ready for real integrations
- Helmet, CORS and rate limiting

## What is intentionally mocked

The real Flash/1Voucher, bank and policy-provider endpoints are **not invented**. The adapter interfaces are ready, but real credentials/API specifications must be supplied before switching from mock providers to live providers.

## Run locally

1. Create a PostgreSQL/Supabase database.
2. Run `sql/001_init.sql`.
3. Copy `.env.example` to `.env` and set `DATABASE_URL` and `PIN_PEPPER`.
4. Install dependencies:

```bash
npm install
```

5. Start:

```bash
npm run dev
```

Health check:

```bash
curl http://localhost:3000/health
```

## First end-to-end test

Create a user:

```bash
curl -X POST http://localhost:3000/v1/users \\
  -H 'content-type: application/json' \\
  -d '{"phone":"+27821234567","firstName":"Thabo"}'
```

Set a 5-digit PIN using the returned user ID.

Deposit a demo 1Voucher. In mock mode, a 16-digit voucher beginning with `10`, `20`, or `50` represents R100, R200 or R500 respectively.

```bash
curl -X POST http://localhost:3000/v1/wallet/deposit \\
  -H 'content-type: application/json' \\
  -H 'x-user-id: USER_ID' \\
  -H 'idempotency-key: dep-001' \\
  -d '{"voucher":"2000000000000000"}'
```

Check balance:

```bash
curl http://localhost:3000/v1/wallet -H 'x-user-id: USER_ID'
```

## Architecture

```text
WhatsApp / Infobip / Meta
          |
          v
    Skotokoto Channel
          |
          v
 +-----------------------+
 | eVoucha Orchestration |
 | API                   |
 +-----------+-----------+
             |
     +-------+-------+-------+
     |               |       |
     v               v       v
  Voucher          Bank    Policy
  Adapter          Adapter Adapter
     |               |       |
  1Voucher         Bank 1  Insurer/Biller

             |
             v
       PostgreSQL Ledger
```

The core API does not depend on a provider-specific implementation. Providers are adapters.

## Production hardening still required

- Real provider API implementations and credentials
- OAuth/API-key/MTLS as required by each partner
- Webhook signature verification
- Stronger authentication/session model than the development `x-user-id` header
- Transaction reservation/ledger model for asynchronous providers
- Provider reconciliation jobs
- Fraud/risk rules
- Observability and alerting
- Secrets management
- Automated integration tests against partner sandboxes
- Formal security review and penetration testing
