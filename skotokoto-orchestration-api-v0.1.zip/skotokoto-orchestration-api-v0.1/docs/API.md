# API Contract v0.1

## Core endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/health` | Service health |
| POST | `/v1/users` | Create customer |
| POST | `/v1/users/:userId/pin` | Set 5-digit PIN |
| POST | `/v1/users/:userId/pin/verify` | Verify PIN |
| GET | `/v1/wallet` | Current balance |
| GET | `/v1/wallet/transactions` | Transaction history |
| POST | `/v1/wallet/deposit` | Load/redeem voucher |
| POST | `/v1/transfers` | Send money |
| POST | `/v1/wallet/withdraw` | Issue bank voucher |
| POST | `/v1/payments/policy` | Pay policy |

Financial write endpoints require `Idempotency-Key`.

## Money representation

External API amounts are ZAR rand values. Internal storage uses integer cents (`amount_minor`, `balance_minor`) to avoid floating-point money calculations.

## Provider abstraction

The orchestration layer exposes business capabilities rather than provider endpoints. This allows `1VOUCHER`, `BANK_1`, and `POLICY_1` to be replaced/expanded without changing the Skotokoto channel contract.
