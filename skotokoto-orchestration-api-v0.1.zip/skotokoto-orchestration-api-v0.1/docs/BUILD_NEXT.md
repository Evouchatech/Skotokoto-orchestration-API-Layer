# Build sequence after v0.1

1. Connect a Supabase PostgreSQL database and run the migration.
2. Replace the development `x-user-id` header with real auth/session tokens.
3. Obtain the actual Flash/1Voucher API specification and sandbox credentials.
4. Implement `OneVoucherProvider` against the supplied specification.
5. Obtain the first bank voucher API specification and sandbox credentials.
6. Implement `BankVoucherProvider`.
7. Obtain policy/biller API specification and implement `PolicyProvider`.
8. Add signed webhooks and reconciliation.
9. Add WhatsApp/Infobip webhook adapter.
10. Build the Skotokoto conversational state machine on top of these stable API contracts.
