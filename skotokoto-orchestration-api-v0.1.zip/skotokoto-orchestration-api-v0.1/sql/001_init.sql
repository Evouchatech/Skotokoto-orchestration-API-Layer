create extension if not exists pgcrypto;

create table if not exists users (
  id uuid primary key default gen_random_uuid(),
  phone_e164 varchar(20) not null unique,
  first_name text,
  last_name text,
  pin_hash text,
  status text not null default 'active' check (status in ('active','blocked','pending')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists wallets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null unique references users(id),
  currency char(3) not null default 'ZAR',
  balance_minor bigint not null default 0 check (balance_minor >= 0),
  status text not null default 'active' check (status in ('active','blocked','closed')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists transactions (
  id uuid primary key default gen_random_uuid(),
  wallet_id uuid not null references wallets(id),
  type text not null check (type in ('deposit','transfer_out','transfer_in','withdrawal','policy_payment','reversal')),
  status text not null check (status in ('pending','processing','completed','failed','reversed')),
  amount_minor bigint not null check (amount_minor > 0),
  currency char(3) not null default 'ZAR',
  reference text,
  provider text,
  provider_reference text,
  metadata jsonb not null default '{}',
  created_at timestamptz not null default now(),
  completed_at timestamptz
);

create index if not exists idx_transactions_wallet_created on transactions(wallet_id, created_at desc);

create table if not exists transaction_events (
  id bigserial primary key,
  transaction_id uuid not null references transactions(id),
  event_type text not null,
  payload jsonb not null default '{}',
  created_at timestamptz not null default now()
);

create table if not exists idempotency_keys (
  id uuid primary key default gen_random_uuid(),
  scope text not null,
  idempotency_key text not null,
  request_hash text not null,
  response_status integer,
  response_body jsonb,
  created_at timestamptz not null default now(),
  unique(scope, idempotency_key)
);

create table if not exists provider_transactions (
  id uuid primary key default gen_random_uuid(),
  provider text not null,
  provider_reference text not null,
  transaction_id uuid references transactions(id),
  status text not null,
  raw_response jsonb not null default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(provider, provider_reference)
);

create table if not exists webhook_events (
  id uuid primary key default gen_random_uuid(),
  provider text not null,
  event_id text not null,
  payload jsonb not null,
  received_at timestamptz not null default now(),
  processed_at timestamptz,
  unique(provider, event_id)
);

create table if not exists audit_logs (
  id bigserial primary key,
  actor_type text not null,
  actor_id text,
  action text not null,
  resource_type text,
  resource_id text,
  metadata jsonb not null default '{}',
  created_at timestamptz not null default now()
);
