import type { BankVoucherProvider, PolicyProvider, VoucherProvider } from '../types.js';

export class MockOneVoucherProvider implements VoucherProvider {
  async validateAndRedeem(voucher: string) {
    // Demo rule: 16 digits; amount is encoded by the first two digits: 10 => R100, 20 => R200, 50 => R500.
    if (!/^\d{16}$/.test(voucher)) return { valid: false, currency: 'ZAR' as const };
    const prefix = voucher.slice(0, 2);
    const map: Record<string, number> = { '10': 10000, '20': 20000, '50': 50000 };
    const amountMinor = map[prefix] ?? 10000;
    return { valid: true, amountMinor, currency: 'ZAR' as const, providerReference: `MOCK-1V-${voucher.slice(-8)}` };
  }
}

export class MockBankVoucherProvider implements BankVoucherProvider {
  async issueVoucher(input: { amountMinor: number; recipientPhone: string; reference?: string }) {
    const voucherNumber = Array.from({ length: 10 }, () => Math.floor(Math.random() * 10)).join('');
    const pin = Array.from({ length: 4 }, () => Math.floor(Math.random() * 10)).join('');
    return { status: 'completed' as const, voucherNumber, pin, providerReference: `MOCK-BANK-${Date.now()}` };
  }
}

export class MockPolicyProvider implements PolicyProvider {
  async payPolicy(input: { policyNumber: string; amountMinor: number; reference?: string }) {
    return { status: 'completed' as const, providerReference: `MOCK-POLICY-${input.policyNumber}` };
  }
}
