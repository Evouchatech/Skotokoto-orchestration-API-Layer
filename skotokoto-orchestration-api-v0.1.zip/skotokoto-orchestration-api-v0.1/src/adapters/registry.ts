import { MockBankVoucherProvider, MockOneVoucherProvider, MockPolicyProvider } from './mock.js';

export const providers = {
  voucher: { '1VOUCHER': new MockOneVoucherProvider() },
  bank: { 'BANK_1': new MockBankVoucherProvider() },
  policy: { 'POLICY_1': new MockPolicyProvider() }
};
