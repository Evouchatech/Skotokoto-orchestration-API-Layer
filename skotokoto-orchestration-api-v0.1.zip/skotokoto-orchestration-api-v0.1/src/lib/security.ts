import { randomBytes, scrypt as _scrypt, timingSafeEqual, createHash } from 'node:crypto';
import { promisify } from 'node:util';
const scrypt = promisify(_scrypt);

export async function hashPin(pin: string): Promise<string> {
  const salt = randomBytes(16).toString('hex');
  const pepper = process.env.PIN_PEPPER ?? '';
  const derived = await scrypt(pin + pepper, salt, 64) as Buffer;
  return `${salt}:${derived.toString('hex')}`;
}

export async function verifyPin(pin: string, stored: string): Promise<boolean> {
  const [salt, hex] = stored.split(':');
  if (!salt || !hex) return false;
  const pepper = process.env.PIN_PEPPER ?? '';
  const derived = await scrypt(pin + pepper, salt, 64) as Buffer;
  const expected = Buffer.from(hex, 'hex');
  return expected.length === derived.length && timingSafeEqual(expected, derived);
}

export function hashRequest(value: unknown): string {
  return createHash('sha256').update(JSON.stringify(value)).digest('hex');
}

export function maskSecret(value: string): string {
  if (value.length <= 4) return '****';
  return `${value.slice(0, 2)}****${value.slice(-2)}`;
}
