import type { FastifyInstance, FastifyRequest } from 'fastify';
import { z } from 'zod';
import { createUser, deposit, getUserByPhone, getWallet, payPolicy, setUserPin, transfer, withdraw } from '../services/wallet.js';
import { hashPin, verifyPin } from '../lib/security.js';
import { pool } from '../lib/db.js';

const phone = z.string().regex(/^\+27\d{9}$/);
const amount = z.number().int().positive().max(1_000_000);

async function requireUser(request: FastifyRequest) {
  const userId = String(request.headers['x-user-id'] ?? '');
  if (!userId) throw new Error('AUTH_REQUIRED');
  return userId;
}

export async function registerRoutes(app: FastifyInstance) {
  app.get('/health', async () => ({ status: 'ok', service: 'skotokoto-orchestration-api', mockProviders: process.env.MOCK_PROVIDERS === 'true' }));

  app.post('/v1/users', async (request, reply) => {
    const body = z.object({ phone: phone, firstName: z.string().min(1).max(80).optional(), lastName: z.string().max(80).optional() }).parse(request.body);
    const existing = await getUserByPhone(body.phone);
    if (existing) return reply.code(409).send({ error: 'USER_EXISTS' });
    const user = await createUser(body.phone, body.firstName, body.lastName);
    return reply.code(201).send(user);
  });

  app.post('/v1/users/:userId/pin', async (request, reply) => {
    const params = z.object({ userId: z.string().uuid() }).parse(request.params);
    const body = z.object({ pin: z.string().regex(/^\d{5}$/) }).parse(request.body);
    await setUserPin(params.userId, await hashPin(body.pin));
    return reply.send({ status: 'ok' });
  });

  app.post('/v1/users/:userId/pin/verify', async (request) => {
    const params = z.object({ userId: z.string().uuid() }).parse(request.params);
    const body = z.object({ pin: z.string().regex(/^\d{5}$/) }).parse(request.body);
    const result = await pool.query('select pin_hash from users where id=$1', [params.userId]);
    if (!result.rowCount || !result.rows[0].pin_hash || !(await verifyPin(body.pin, result.rows[0].pin_hash))) throw new Error('INVALID_PIN');
    return { valid: true };
  });

  app.get('/v1/wallet', async (request) => getWallet(await requireUser(request)));

  app.get('/v1/wallet/transactions', async (request) => {
    const userId = await requireUser(request);
    const rows = await pool.query(`select t.id,t.type,t.status,t.amount_minor,t.currency,t.reference,t.provider,t.created_at,t.completed_at from transactions t join wallets w on w.id=t.wallet_id where w.user_id=$1 order by t.created_at desc limit 100`, [userId]);
    return { transactions: rows.rows.map(r => ({ ...r, amount: Number(r.amount_minor) / 100 })) };
  });

  app.post('/v1/wallet/deposit', async (request, reply) => {
    const userId = await requireUser(request);
    const idem = String(request.headers['idempotency-key'] ?? '');
    if (!idem) return reply.code(400).send({ error: 'IDEMPOTENCY_KEY_REQUIRED' });
    const body = z.object({ voucher: z.string().regex(/^\d{16}$/) }).parse(request.body);
    return deposit(userId, body.voucher, idem);
  });

  app.post('/v1/transfers', async (request, reply) => {
    const userId = await requireUser(request);
    const idem = String(request.headers['idempotency-key'] ?? '');
    if (!idem) return reply.code(400).send({ error: 'IDEMPOTENCY_KEY_REQUIRED' });
    const body = z.object({ recipient: phone, amount, reference: z.string().max(80).optional() }).parse(request.body);
    return transfer(userId, body.recipient, body.amount * 100, body.reference, idem);
  });

  app.post('/v1/wallet/withdraw', async (request, reply) => {
    const userId = await requireUser(request);
    const idem = String(request.headers['idempotency-key'] ?? '');
    if (!idem) return reply.code(400).send({ error: 'IDEMPOTENCY_KEY_REQUIRED' });
    const body = z.object({ amount, bank: z.literal('BANK_1'), reference: z.string().max(80).optional() }).parse(request.body);
    return withdraw(userId, body.amount * 100, body.bank, body.reference, idem);
  });

  app.post('/v1/payments/policy', async (request, reply) => {
    const userId = await requireUser(request);
    const idem = String(request.headers['idempotency-key'] ?? '');
    if (!idem) return reply.code(400).send({ error: 'IDEMPOTENCY_KEY_REQUIRED' });
    const body = z.object({ policyNumber: z.string().min(3).max(80), amount, reference: z.string().max(80).optional() }).parse(request.body);
    return payPolicy(userId, body.policyNumber, body.amount * 100, body.reference, idem);
  });
}
