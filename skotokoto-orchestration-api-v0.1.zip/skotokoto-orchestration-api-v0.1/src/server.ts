import Fastify from 'fastify';
import cors from '@fastify/cors';
import helmet from '@fastify/helmet';
import rateLimit from '@fastify/rate-limit';
import { registerRoutes } from './routes/api.js';

const app = Fastify({ logger: true });
await app.register(cors, { origin: false });
await app.register(helmet);
await app.register(rateLimit, { max: 100, timeWindow: '1 minute' });

app.setErrorHandler((error, request, reply) => {
  request.log.error(error);
  const known: Record<string, number> = {
    AUTH_REQUIRED: 401,
    USER_NOT_FOUND: 404,
    WALLET_NOT_FOUND: 404,
    RECIPIENT_NOT_FOUND: 404,
    INVALID_VOUCHER: 422,
    INVALID_PIN: 401,
    INSUFFICIENT_FUNDS: 422,
    IDEMPOTENCY_KEY_REUSED: 409,
    SELF_TRANSFER: 422
  };
  const status = known[error.message] ?? (error.name === 'ZodError' ? 400 : 500);
  reply.code(status).send({ error: error.message });
});

await registerRoutes(app);

const port = Number(process.env.PORT ?? 3000);
await app.listen({ port, host: '0.0.0.0' });
