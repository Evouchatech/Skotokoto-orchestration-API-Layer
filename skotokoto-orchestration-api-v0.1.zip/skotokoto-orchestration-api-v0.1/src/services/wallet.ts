import type { PoolClient } from 'pg';
import { tx } from '../lib/db.js';
import { hashRequest } from '../lib/security.js';
import { providers } from '../adapters/registry.js';

export async function getUserByPhone(phone: string) {
  const result = await (await import('../lib/db.js')).pool.query('select id, phone_e164, first_name, last_name, status from users where phone_e164=$1', [phone]);
  return result.rows[0] ?? null;
}

export async function createUser(phone: string, firstName?: string, lastName?: string) {
  return tx(async client => {
    const user = await client.query('insert into users(phone_e164, first_name, last_name) values($1,$2,$3) returning id, phone_e164, first_name, last_name, status', [phone, firstName ?? null, lastName ?? null]);
    await client.query('insert into wallets(user_id) values($1)', [user.rows[0].id]);
    return user.rows[0];
  });
}

export async function setUserPin(userId: string, pinHash: string) {
  await (await import('../lib/db.js')).pool.query('update users set pin_hash=$1, updated_at=now() where id=$2', [pinHash, userId]);
}

export async function getWallet(userId: string) {
  const result = await (await import('../lib/db.js')).pool.query(`select w.id, w.currency, w.balance_minor, w.status from wallets w where w.user_id=$1`, [userId]);
  return result.rows[0] ?? null;
}

export async function deposit(userId: string, voucher: string, idemKey: string) {
  const requestHash = hashRequest({ userId, voucher });
  return tx(async client => {
    const existing = await client.query('select response_status, response_body, request_hash from idempotency_keys where scope=$1 and idempotency_key=$2', ['deposit', idemKey]);
    if (existing.rowCount) {
      if (existing.rows[0].request_hash !== requestHash) throw new Error('IDEMPOTENCY_KEY_REUSED');
      return existing.rows[0].response_body;
    }
    const user = await client.query('select id from users where id=$1 for update', [userId]);
    if (!user.rowCount) throw new Error('USER_NOT_FOUND');
    const wallet = await client.query('select id from wallets where user_id=$1 for update', [userId]);
    const validation = await providers.voucher['1VOUCHER'].validateAndRedeem(voucher);
    if (!validation.valid || !validation.amountMinor) throw new Error('INVALID_VOUCHER');
    const transaction = await client.query(`insert into transactions(wallet_id,type,status,amount_minor,currency,provider,provider_reference,metadata,completed_at) values($1,'deposit','completed',$2,$3,'1VOUCHER',$4,$5,now()) returning id, amount_minor, currency, status`, [wallet.rows[0].id, validation.amountMinor, validation.currency, validation.providerReference, JSON.stringify({ voucherLast4: voucher.slice(-4) })]);
    await client.query('update wallets set balance_minor=balance_minor+$1, updated_at=now() where id=$2', [validation.amountMinor, wallet.rows[0].id]);
    await client.query('insert into transaction_events(transaction_id,event_type,payload) values($1,$2,$3)', [transaction.rows[0].id, 'deposit.completed', JSON.stringify({ provider: '1VOUCHER', providerReference: validation.providerReference })]);
    const response = { transactionId: transaction.rows[0].id, status: 'completed', amount: validation.amountMinor / 100, currency: validation.currency };
    await client.query('insert into idempotency_keys(scope,idempotency_key,request_hash,response_status,response_body) values($1,$2,$3,200,$4)', ['deposit', idemKey, requestHash, JSON.stringify(response)]);
    return response;
  });
}

export async function transfer(senderUserId: string, recipientPhone: string, amountMinor: number, reference: string | undefined, idemKey: string) {
  const requestHash = hashRequest({ senderUserId, recipientPhone, amountMinor, reference });
  return tx(async client => {
    const existing = await client.query('select response_body, request_hash from idempotency_keys where scope=$1 and idempotency_key=$2', ['transfer', idemKey]);
    if (existing.rowCount) {
      if (existing.rows[0].request_hash !== requestHash) throw new Error('IDEMPOTENCY_KEY_REUSED');
      return existing.rows[0].response_body;
    }
    const sender = await client.query('select id from wallets where user_id=$1 for update', [senderUserId]);
    if (!sender.rowCount) throw new Error('WALLET_NOT_FOUND');
    const recipient = await client.query('select u.id, w.id as wallet_id from users u join wallets w on w.user_id=u.id where u.phone_e164=$1 for update', [recipientPhone]);
    if (!recipient.rowCount) throw new Error('RECIPIENT_NOT_FOUND');
    if (recipient.rows[0].id === senderUserId) throw new Error('SELF_TRANSFER');
    const balance = await client.query('select balance_minor from wallets where id=$1 for update', [sender.rows[0].id]);
    if (Number(balance.rows[0].balance_minor) < amountMinor) throw new Error('INSUFFICIENT_FUNDS');
    const out = await client.query(`insert into transactions(wallet_id,type,status,amount_minor,reference,provider,metadata,completed_at) values($1,'transfer_out','completed',$2,$3,'EVOUCHA',$4,now()) returning id`, [sender.rows[0].id, amountMinor, reference ?? null, JSON.stringify({ recipientPhone })]);
    const incoming = await client.query(`insert into transactions(wallet_id,type,status,amount_minor,reference,provider,metadata,completed_at) values($1,'transfer_in','completed',$2,$3,'EVOUCHA',$4,now()) returning id`, [recipient.rows[0].wallet_id, amountMinor, reference ?? null, JSON.stringify({ senderUserId })]);
    await client.query('update wallets set balance_minor=balance_minor-$1, updated_at=now() where id=$2', [amountMinor, sender.rows[0].id]);
    await client.query('update wallets set balance_minor=balance_minor+$1, updated_at=now() where id=$2', [amountMinor, recipient.rows[0].wallet_id]);
    const response = { transactionId: out.rows[0].id, recipientTransactionId: incoming.rows[0].id, status: 'completed', amount: amountMinor / 100, currency: 'ZAR' };
    await client.query('insert into idempotency_keys(scope,idempotency_key,request_hash,response_status,response_body) values($1,$2,$3,200,$4)', ['transfer', idemKey, requestHash, JSON.stringify(response)]);
    return response;
  });
}

export async function withdraw(userId: string, amountMinor: number, bank: 'BANK_1', reference: string | undefined, idemKey: string) {
  const requestHash = hashRequest({ userId, amountMinor, bank, reference });
  return tx(async client => {
    const existing = await client.query('select response_body, request_hash from idempotency_keys where scope=$1 and idempotency_key=$2', ['withdraw', idemKey]);
    if (existing.rowCount) {
      if (existing.rows[0].request_hash !== requestHash) throw new Error('IDEMPOTENCY_KEY_REUSED');
      return existing.rows[0].response_body;
    }
    const wallet = await client.query('select id,balance_minor from wallets where user_id=$1 for update', [userId]);
    if (!wallet.rowCount) throw new Error('WALLET_NOT_FOUND');
    if (Number(wallet.rows[0].balance_minor) < amountMinor) throw new Error('INSUFFICIENT_FUNDS');
    const user = await client.query('select phone_e164 from users where id=$1', [userId]);
    const issued = await providers.bank[bank].issueVoucher({ amountMinor, recipientPhone: user.rows[0].phone_e164, reference });
    const t = await client.query(`insert into transactions(wallet_id,type,status,amount_minor,currency,reference,provider,provider_reference,metadata,completed_at) values($1,'withdrawal',$2,$3,'ZAR',$4,$5,$6,$7,case when $2='completed' then now() else null end) returning id`, [wallet.rows[0].id, issued.status, amountMinor, reference ?? null, bank, issued.providerReference, JSON.stringify({ voucherLast4: issued.voucherNumber?.slice(-4) ?? null })]);
    if (issued.status === 'completed') await client.query('update wallets set balance_minor=balance_minor-$1, updated_at=now() where id=$2', [amountMinor, wallet.rows[0].id]);
    const response = { transactionId: t.rows[0].id, status: issued.status, amount: amountMinor / 100, currency: 'ZAR', voucher: { number: issued.voucherNumber, pin: issued.pin } };
    await client.query('insert into idempotency_keys(scope,idempotency_key,request_hash,response_status,response_body) values($1,$2,$3,200,$4)', ['withdraw', idemKey, requestHash, JSON.stringify(response)]);
    return response;
  });
}

export async function payPolicy(userId: string, policyNumber: string, amountMinor: number, reference: string | undefined, idemKey: string) {
  const requestHash = hashRequest({ userId, policyNumber, amountMinor, reference });
  return tx(async client => {
    const existing = await client.query('select response_body, request_hash from idempotency_keys where scope=$1 and idempotency_key=$2', ['policy', idemKey]);
    if (existing.rowCount) {
      if (existing.rows[0].request_hash !== requestHash) throw new Error('IDEMPOTENCY_KEY_REUSED');
      return existing.rows[0].response_body;
    }
    const wallet = await client.query('select id,balance_minor from wallets where user_id=$1 for update', [userId]);
    if (!wallet.rowCount) throw new Error('WALLET_NOT_FOUND');
    if (Number(wallet.rows[0].balance_minor) < amountMinor) throw new Error('INSUFFICIENT_FUNDS');
    const result = await providers.policy['POLICY_1'].payPolicy({ policyNumber, amountMinor, reference });
    const t = await client.query(`insert into transactions(wallet_id,type,status,amount_minor,currency,reference,provider,provider_reference,metadata,completed_at) values($1,'policy_payment',$2,$3,'ZAR',$4,'POLICY_1',$5,$6,case when $2='completed' then now() else null end) returning id`, [wallet.rows[0].id, result.status, amountMinor, reference ?? null, result.providerReference, JSON.stringify({ policyNumberLast4: policyNumber.slice(-4) })]);
    if (result.status === 'completed') await client.query('update wallets set balance_minor=balance_minor-$1, updated_at=now() where id=$2', [amountMinor, wallet.rows[0].id]);
    const response = { transactionId: t.rows[0].id, status: result.status, amount: amountMinor / 100, currency: 'ZAR' };
    await client.query('insert into idempotency_keys(scope,idempotency_key,request_hash,response_status,response_body) values($1,$2,$3,200,$4)', ['policy', idemKey, requestHash, JSON.stringify(response)]);
    return response;
  });
}
