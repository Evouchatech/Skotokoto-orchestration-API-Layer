export type VoucherValidation = {
  valid: boolean;
  amountMinor?: number;
  currency: 'ZAR';
  providerReference?: string;
};

export type WithdrawalResult = {
  status: 'completed' | 'pending';
  voucherNumber?: string;
  pin?: string;
  providerReference: string;
};

export interface VoucherProvider {
  validateAndRedeem(voucher: string): Promise<VoucherValidation>;
}

export interface BankVoucherProvider {
  issueVoucher(input: { amountMinor: number; recipientPhone: string; reference?: string }): Promise<WithdrawalResult>;
}

export interface PolicyProvider {
  payPolicy(input: { policyNumber: string; amountMinor: number; reference?: string }): Promise<{ status: 'completed' | 'pending'; providerReference: string }>;
}
