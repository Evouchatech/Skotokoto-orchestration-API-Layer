import test from 'node:test';
import assert from 'node:assert/strict';
import { z } from 'zod';

test('South African E.164 phone contract', () => {
  const phone = z.string().regex(/^\+27\d{9}$/);
  assert.equal(phone.safeParse('+27821234567').success, true);
  assert.equal(phone.safeParse('0821234567').success, false);
});
