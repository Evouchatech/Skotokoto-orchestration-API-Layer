import test from 'node:test';
import assert from 'node:assert/strict';
import { hashPin, verifyPin } from '../src/lib/security.js';

test('PIN hashes verify and wrong PIN fails', async () => {
  process.env.PIN_PEPPER = 'test-pepper';
  const hash = await hashPin('12345');
  assert.equal(await verifyPin('12345', hash), true);
  assert.equal(await verifyPin('54321', hash), false);
});
